#!/usr/bin/env python3
"""Generate KLE JSON for the Camber ortholinear splay layout.
Canonical layout — hand-tuned to match the DXF plate.
Each key is its own row (separate []) — required for KLE rotation to work correctly."""
import json

# Canonical KLE layout. Each key gets its own [] array.
# When r/rx/ry change, they appear on the first key of that column.
# Subsequent keys in the same column inherit r and rx/ry, only need x/y offsets.
kle = [
    [{"x":6.4918,"y":2.7943,"a":7,"h":1.25},"Space"],
    [{"r":2,"rx":0.7093,"ry":2.0443,"x":-0.5,"y":-2},"Esc"],
    [{"x":-0.5},"Tab"],
    [{"x":-0.5},"Caps"],
    [{"x":-0.5},"Shift"],
    [{"r":4,"rx":1.788,"x":-0.5,"y":-2},"`"],
    [{"x":-0.5},"Q"],
    [{"x":-0.5},"A"],
    [{"x":-0.5},"Z"],
    [{"r":6,"rx":2.8668,"x":-0.5,"y":-2},"1"],
    [{"x":-0.5},"W"],
    [{"x":-0.5},"S"],
    [{"x":-0.5},"X"],
    [{"rx":3.8668,"x":-0.5,"y":-2},"2"],
    [{"x":-0.5},"E"],
    [{"x":-0.5},"D"],
    [{"x":-0.5},"C"],
    [{"rx":4.8668,"x":-0.5,"y":-2},"3"],
    [{"x":-0.5},"R"],
    [{"x":-0.5},"F"],
    [{"x":-0.5},"V"],
    [{"rx":5.8668,"x":-0.5,"y":-2},"4"],
    [{"x":-0.5},"T"],
    [{"x":-0.5},"G"],
    [{"x":-0.5},"B"],
    [{"r":-6,"rx":8.1168,"x":-0.5,"y":-2},"5"],
    [{"x":-0.5},"Y"],
    [{"x":-0.5},"H"],
    [{"x":-0.5},"N"],
    [{"rx":9.1168,"x":-0.5,"y":-2},"6"],
    [{"x":-0.5},"U"],
    [{"x":-0.5},"J"],
    [{"x":-0.5},"M"],
    [{"rx":10.1168,"x":-0.5,"y":-2},"7"],
    [{"x":-0.5},"I"],
    [{"x":-0.5},"K"],
    [{"x":-0.5},","],
    [{"r":-4,"rx":11.1955,"x":-0.5,"y":-2},"8"],
    [{"x":-0.5},"O"],
    [{"x":-0.5},"L"],
    [{"x":-0.5},"."],
    [{"r":-2,"rx":12.2742,"x":-0.5,"y":-2},"9"],
    [{"x":-0.5},"P"],
    [{"x":-0.5},";"],
    [{"x":-0.5},"/"],
]

output = json.dumps(kle, separators=(',', ':'))
with open('kle/camber.kle.json', 'w') as f:
    f.write(output)
print("KLE written to camber.kle.json")
