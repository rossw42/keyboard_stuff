# Alice Keyboard in Minivan Case

*Source: [ChatGPT Shared Conversation](https://chatgpt.com/share/69dd030d-57dc-8329-82d6-861345be3925)*

---

## User

Do you think we could fit an Alice style keyboard in a minivan case?

## ChatGPT

Short answer: yes, but it depends heavily on what you mean by "minivan case." If you mean a Planck-style 40% unibody case, then this gets tricky.

### 1. Alice layout footprint

An Alice-style board is not just "a little wider" — it fundamentally changes geometry:

- Angled halves (∧ shape)
- Central gap + duplicated keys (like split B)
- Usually 65%–75% width class

Typical real-world width:
- ~320–360 mm wide (similar to TKL width, just shaped differently)
- Depth similar to a compact board (~110–130 mm)

### 2. Planck / 40% "minivan-style" case constraints

A Planck/Minivan class case is roughly:
- ~230 mm wide
- Tight rectangular footprint
- Designed for ortholinear 12×4 or similar grids

This creates two hard constraints:

**A. Width ceiling (biggest blocker)**
- Alice halves still need lateral separation for ergonomics
- You can't "stack" them without breaking the concept
- You're short ~80–120 mm of horizontal space.

**B. Geometry mismatch**

Planck-style cases assume:
- Straight rows
- Rectangular PCB
- No center angle

Alice requires:
- Angled PCB (or two halves inside one case)
- Non-rectangular plate
- Offset mounting points

### 3. Could you force it? (hacky options)

**Option 1 — "Micro Alice" (the only viable path)**
- 40% Alice variant
- Remove number row and nav cluster
- Compress spacing aggressively
- ~10–11 columns total (split ~5/6)
- Minimal center gap

**Option 2 — Fake Alice inside rectangular case**
- Keep outer case rectangular
- Internally angle switches/plate
- Keycaps will collide or look misaligned
- Plate becomes very custom

**Option 3 — Two PCBs under one "minivan shell"**
- Treat it like a fixed split inside one enclosure
- Use RP2040 (nice!nano / Pro Micro style)
- Width problem remains unless you shrink layout

### 4. Real answer

- A standard Alice layout → NO, it won't fit
- A reduced / 40% Alice hybrid → MAYBE, with compromises

### 5. Recommendation: "Alice-inspired 40% unibody"

- Slight inward angle (5–8° per side)
- No big center gap
- Keep it within ~230–250 mm width
- Use columnar or light stagger (like Sweep influence)

---

## User

How about micro Alice but keep number row and remove nav cluster?

## ChatGPT

That's actually a much more viable configuration — arguably the tightest way to preserve the "Alice feel" while staying near a 40%/Minivan envelope.

### Constraints

- ✅ Keep number row
- ❌ Remove nav cluster
- ✅ Alice-style split + angle
- 🎯 Target: Minivan / Planck-ish width (~230–250 mm)

This is essentially a "60% Alice compressed into a 40% footprint."

### Key insight

The nav cluster is not the real width problem on Alice boards. The real width drivers are:
- Alphas (A–; rows)
- Pinky columns
- Center gap
- Outer mods

Removing nav cluster helps depth, not width. To make this fit, we have to attack column count, center spacing, and key unit sizes.

### Feasible "Micro Alice + Number Row" layout

**Columns:** 5 columns (left) + 6 columns (right) (asymmetric like many Alices)
**Rows:** Number row retained, QWERTY rows intact
**Total:** ~11 columns × 5 rows

### Critical compression tactics

1. **Shrink center gap aggressively** — Standard Alice gap: ~1.5u–2u. You need: ~0.5u–1u.
2. **Reduce outer key sizes** — Use 1u mods instead of 1.25u/1.5u, tighter pinky columns.
3. **Slightly reduce angle** — Standard Alice: ~10–15°. You want: 5–8°.
4. **Optional: drop duplicate B** — Saves space and simplifies routing.

### Rough width math

- 11 columns × 19.05 mm = ~210 mm
- Add small center gap (~10–15 mm) + minimal bezel
- Final: ~225–245 mm total width ✅

### PCB / wiring implications

- Matrix: ~5 rows × 11 columns = 16 pins (fits most MCUs easily)
- Routing: Slightly harder due to angles, still trivial for handwire

### Keycap compatibility concern

- MT3 = sculpted → breaks on nonstandard columns
- Better options: DSA, XDA, or uniform profile

---

## User

Yeah only 1u keys except maybe the spaces.

## ChatGPT

Going all-1u (except thumbs) removes 90% of the geometric friction that normally kills compact Alice attempts.

### "Micro Alice + Number Row (All 1u)" architecture

**Core grid:**
- 11 columns total (5 left / 6 right)
- 5 rows (number row included)
- Thumb row: 2–4 keys (can be >1u)

### Geometry

**Horizontal math:**
- 11 × 19.05 mm = 209.55 mm
- Center gap: 8–12 mm (tight)
- Edge margins: ~5–10 mm total
- Final width: ~222–235 mm ✅

**Angle tuning:**
- Recommended: 6° per half (sweet spot)
- Absolute max: 8°

### Center gap strategy

**Option A — "Visual split only" (recommended)**
- ~8–10 mm gap, no extra key in the middle
- Clean, compact, still feels Alice-like

**Option B — "Micro gap + inner columns"**
- Practically no gap, just a slight angle break
- Maximum compactness, loses Alice identity slightly

**Option C — "Functional center (1u key)"**
- Put a 1u key in the middle (layer, fn, etc.)
- Efficient, starts to feel ortholinear again

### Thumb cluster options

**Minimal:** 2 × 1.5u spacebars (split), slight inward angle
**Functional:** 4 × 1u keys + 1 × 2u space
**Ergonomic sweet spot:** 2–3 keys per side, slight arc

### Keycap profiles

- DSA → safest
- XDA → slightly larger feel
- KAM → premium + uniform
- MTNU / MT4 → higher-end sculpt feel without strict row dependence

### What it will feel like

- Closer to a Sweep than a full Alice
- Natural wrist inward angle, better pinky reach, less ulnar deviation
- "Alice ergonomics distilled into a 40% form factor"

---

## User

Can you show me a pic of option A?

## ChatGPT

*(Reference images of standard Alice boards were shown for orientation.)*

### How this maps to Micro Alice (Option A)

What stays the same:
- ✅ Split "∧" shape (core Alice concept)
- ✅ Two angled halves
- ✅ Visible center gap
- ✅ Split thumb area

What changes:

| Feature | Standard Alice | Your Micro Alice |
|---------|---------------|-----------------|
| Width | ~320–360 mm | ~225–235 mm |
| Center gap | Wide (~1.5–2u) | Tight (~8–10 mm) |
| Mods | Mixed sizes | All 1u |
| Nav cluster | Present | ❌ Removed |
| Number row | ✅ | ✅ (kept) |
| Angle | 10–15° | ~6° (reduced) |

### Mental picture

Imagine taking a standard Alice and:
1. Squeezing both halves inward
2. Shrinking the gap to just a narrow seam
3. Removing all chunky mods
4. Flattening the angle slightly

You end up with something that looks like a Planck stretched sideways but with a subtle Alice bend in the middle.

---

## User

How about just the KLE?

## ChatGPT

### Micro Alice (Option A) – KLE JSON

```json
[
  { "name": "Micro Alice 40% w/ Num Row (Option A)", "author": "ChatGPT" },
  // Number Row (angled halves)
  [{ "x": 0, "y": 0 }, "1","2","3","4","5",
   { "x": 1.5 }, "6","7","8","9","0","-"],
  // Q row
  [{ "x": 0.2, "y": 1 }, "Q","W","E","R","T",
   { "x": 1.5 }, "Y","U","I","O","P","["],
  // Home row
  [{ "x": 0.4, "y": 2 }, "A","S","D","F","G",
   { "x": 1.5 }, "H","J","K","L",";","'"],
  // Bottom alpha row
  [{ "x": 0.6, "y": 3 }, "Z","X","C","V","B",
   { "x": 1.5 }, "N","M",",",".","/","\\"],
  // Thumb row (slightly tucked)
  [{ "x": 1.5, "y": 4 }, "Ctl","Alt","GUI",
   { "w": 2 }, "Space",
   { "x": 1 }, "Space",
   { "w": 1 }, "Fn","Alt","Ctl"]
]
```

Notes:
- The `{ "x": 1.5 }` is the Option A gap (~28.5 mm visual gap in KLE). For real build, compress to 0.5u–0.75u (~10–15 mm).
- KLE doesn't do true per-half rotation well here — gradual x offsets per row fake the angle.
- In CAD, replace with ~6° rotation per half.
- Left: 5 columns, Right: 6 columns (Alice asymmetry).

---

## User

KLE does do key rotation, you didn't use it.

## ChatGPT

You're absolutely right — KLE does support per-key rotation (`r`, `rx`, `ry`). Here's a corrected version using true rotation for each half.

### Micro Alice (Option A) – KLE with proper rotation

```json
[
  { "name": "Micro Alice 40% w/ Num Row (Rotated)", "author": "ChatGPT" },
  // LEFT HALF (rotated -6° around its center)
  [{ "rx": 2.5, "ry": 2, "r": -6 },
    { "x": -2.5, "y": -2 }, "1","2","3","4","5",
    { "x": -5, "y": 1 }, "Q","W","E","R","T",
    { "x": -5, "y": 1 }, "A","S","D","F","G",
    { "x": -5, "y": 1 }, "Z","X","C","V","B"
  ],
  // RIGHT HALF (rotated +6° around its center)
  [{ "rx": 8.5, "ry": 2, "r": 6 },
    { "x": -2.5, "y": -2 }, "6","7","8","9","0","-",
    { "x": -6, "y": 1 }, "Y","U","I","O","P","[",
    { "x": -6, "y": 1 }, "H","J","K","L",";","'",
    { "x": -6, "y": 1 }, "N","M",",",".","/","\\"
  ],
  // THUMBS (no rotation, slight inward tuck)
  [{ "r": 0 },
    { "x": 2.5, "y": 4 }, "Ctl","Alt","GUI",
    { "w": 2 }, "Space",
    { "x": 1 }, "Space",
    "Fn","Alt","Ctl"
  ]
]
```

Key details:
- Left half rotates around ~column 2.5, right half around ~8.5
- ±6° keeps total width within Minivan constraint
- Center gap is created naturally by rotation + separation between anchor points
- Tighten by reducing distance between the two `rx` anchors

---

## User

*(Uploaded an image of the layout)*

What about the bottom thumb row?

## ChatGPT

The current thumb row is the weak point:
- Thumbs are flat and off to the right
- Not aligned with the rotated halves
- Feels more like a leftover Planck row than an Alice/Split thumb cluster

### Fixes needed

**1. Split the thumb cluster**
- Left thumb cluster + Right thumb cluster
- Small gap between them aligned with center split

**2. Pull thumbs inward**
- Thumbs naturally rest closer to the center, slightly below and inward

**3. Recommended configurations**

**Option A (clean + minimal):** 2 keys per side
```
Alt  Space   ||  Space  Alt
```

**Option B (more power):** 3 keys per side
```
GUI  Alt  Space   ||   Space  Alt  Fn
```

**Option C (ultra compact):** All 1u keys
```
Ctrl Alt GUI   ||   GUI Alt Ctrl
```

**4. Positioning**
- Move up slightly (~0.25–0.5u)
- Inward (~0.5–1u per side)
- Add slight angle (-10° left, +10° right) to match natural thumb arc

---

## User

Option C KLE

## ChatGPT

### Micro Alice – Option C (All 1u Thumbs)

```json
[
  { "name": "Micro Alice 40% - Option C (All 1u Thumbs)", "author": "ChatGPT" },
  // LEFT HALF
  [{ "rx": 2.5, "ry": 2, "r": -6 },
    { "x": -2.5, "y": -2 }, "1","2","3","4","5",
    { "x": -5, "y": 1 }, "Q","W","E","R","T",
    { "x": -5, "y": 1 }, "A","S","D","F","G",
    { "x": -5, "y": 1 }, "Z","X","C","V","B"
  ],
  // RIGHT HALF
  [{ "rx": 8.5, "ry": 2, "r": 6 },
    { "x": -2.5, "y": -2 }, "6","7","8","9","0","-",
    { "x": -6, "y": 1 }, "Y","U","I","O","P","[",
    { "x": -6, "y": 1 }, "H","J","K","L",";","'",
    { "x": -6, "y": 1 }, "N","M",",",".","/","\\"
  ],
  // LEFT THUMB CLUSTER (under B/V area)
  [{ "r": -6, "rx": 2.5, "ry": 5.2 },
    { "x": -1.2, "y": 0 }, "Ctl","Alt","GUI"
  ],
  // RIGHT THUMB CLUSTER (under N/M area)
  [{ "r": 6, "rx": 8.5, "ry": 5.2 },
    { "x": -1.8, "y": 0 }, "GUI","Alt","Ctl"
  ]
]
```

Key details:
- Thumb clusters sit directly under inner columns (B/N region)
- Thumbs inherit -6° (left) and +6° (right) rotation matching the halves
- All 1u = clean for handwiring, tight spacing, uniform keycap profiles
- Thumbs do NOT increase width — they sit inside the alpha footprint

---

## User

Does that fit in a minivan case?

## ChatGPT

Yes — this Option C layout can fit in a Minivan-class case, but you're right on the edge.

### Minivan envelope

- ~230 mm usable internal width
- Safe target: ≤225 mm

### Your layout width

- Base grid: 11 columns × 19.05 mm = 209.5 mm
- Center gap: ~10–15 mm
- Total: ~220–225 mm ✅

### What could break the fit

- ❌ Increasing angle beyond 6°
- ❌ Widening center gap beyond ~15 mm
- ❌ Adding stagger or outward pinky flare

### What keeps it safe

- Pull halves slightly inward (right half `rx: 8.5 → 8.2`)
- Tighten center gap to ~0.5u (~9.5 mm)
- Keep angle at 6° or less

### Fit verdict

| Scenario | Verdict |
|----------|---------|
| Current layout (as posted) | ⚠️ Tight but doable |
| Slightly optimized (recommended tweaks) | ✅ Comfortable fit |
| Larger gap / more angle | ❌ Won't fit |

### Practical build advice

- Leave 2–3 mm clearance per side
- Watch USB port placement, case wall thickness, plate tabs/screws
- Minivan cases aren't super forgiving internally
