# Micro Alice — Project Summary

## Concept

A compact Alice-style keyboard designed to fit inside existing MiniVan tray-mount cases. The goal is 100% compatibility with the many tray-mount MiniVan cases in the community (aluminum, plastic, Carpool, MFR, Hull, Rackmount, etc.).

## Layout

- Alice-style split with ±6° rotation per half
- Number row retained
- Nav cluster removed
- All 1u keys except possibly thumb spacebars
- 11 columns (5 left / 6 right), 5 rows + split thumb cluster
- Visible center gap (~8–10 mm, Option A style)
- Split thumb clusters (Option C — all 1u, 3 keys per side) positioned under B/V and N/M, inheriting the ±6° rotation of each half

## Design Constraints

- PCB must be 4u × 12.75u (the MiniVan standard)
- PCB dimensions: 242.89 mm × 76.20 mm (±0.1 mm tolerance)
- Must use the standard MiniVan tray-mount hole pattern (7× M2, Rev 2+ pattern — coordinates verified from SteamVan KiCad source)
- USB-C port top-right to match existing case cutouts (USB cutout ~12mm wide, positioned toward right side)
- All switches must stay within the case interior cavity (~244–246 mm × ~78–80 mm)
- All components must clear the 7 case standoff positions
- Angled switch placement is internal to the PCB — the PCB outline itself remains rectangular with 3mm radius corners

## Key Decisions

- ±6° angle per half (max 8° before width becomes a problem)
- Center gap kept tight (~0.5u / ~9.5 mm) to stay within the 12.75u envelope
- Thumb clusters rotated to match their respective halves
- Keycap profile: uniform (DSA, XDA, or KAM recommended; MT3 will have row mismatch issues)
- Matrix: ~5 rows × 11 cols = 16 pins, fits RP2040 or ATmega32u4

## Compatibility Target

- All MiniVan tray-mount cases (Rev 2+ 7-hole mounting pattern, verified from SteamVan KiCad source)
- Also compatible with non-tray-mount cases that accept the standard MiniVan PCB outline (Hull, Campsite, Pomelo, etc.)
- Omnibus-style drop-in replacement philosophy
- Custom plate required (angled switch cutouts won't match any existing MiniVan plate file; plate outline must match Omnibus/Hull dimensions including side tabs for Hull case compatibility)
- Rev 1 aluminum cases: partial compatibility (3 of 7 holes align)

## Open Questions

- Exact switch coordinates need to be calculated in mm for CAD
- Custom plate DXF required (angled cutouts won't match standard MiniVan plates)
- Stabilizer needs TBD (all 1u thumbs = no stabs needed unless spacebars go >1u)
- Handwire vs. PCB decision

## Source Material

- [Original ChatGPT conversation](https://chatgpt.com/share/69dd030d-57dc-8329-82d6-861345be3925)
- Saved locally: `chatgpt-alice-keyboard-minivan-case.md`
- Reference dimensions: `minivan-omnibus-measurements.md`
- [Trashman Wiki — MiniVan](https://trashman.wiki/keyboards/minivan)
- [Trashman Wiki — Files page](https://trashman.wiki/files#minivan) (plate DXFs, mount pattern PDFs, foam DXF)
- [SteamVan KiCad source](https://github.com/jmdaly/steamvan) (CC-BY-SA-4.0, verified MiniVan-compatible PCB)
- [Omnibus support guide](https://help.aeternus.co/omnibus/)
- [MiniVan Compatibility Matrix](https://docs.google.com/spreadsheets/d/1Q1mkIIO67bMsw57uznCavpfXVzcDROpAM5NUxizeva4/)
- [MiniVanPlate.xyz](http://www.minivanplate.xyz/) — plate file generator
